
<div class="carousel">

	<div class="slider" id="slider">

		<div class="leftArrow" onclick="decalage(-1)">
			<span class="arrow arrowLeft"></span>
		</div>

		<div class="rightArrow" onclick="decalage(1)">
			<span class="arrow arrowRight"></span>
		</div>

		<div class="Descriptif"><p class="texteDescriptif"></p></div>

	</div>

	<div id="carouselPoint"><div>

</div>
